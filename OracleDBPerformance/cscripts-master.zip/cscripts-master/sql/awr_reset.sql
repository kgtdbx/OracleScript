PRO
PRO AWR state (before)
PRO ~~~~~~~~~
oradebug unit_test kebm_dmp_slv_attrs kewrmafsa_
PRO
PRO AWR reset
PRO ~~~~~~~~~
oradebug unit_test kebm_set_slv_attrs kewrmafsa_ retain retain retain retain 0 0
PRO
PRO AWR state (after)
PRO ~~~~~~~~~
oradebug unit_test kebm_dmp_slv_attrs kewrmafsa_
--
-- consider _awr_mmon_cpuusage
--