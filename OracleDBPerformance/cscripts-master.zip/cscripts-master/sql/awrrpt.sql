@$ORACLE_HOME/rdbms/admin/awrrpt.sql
