HOS rm /u01/app/oracle/tools/cscripts/sql/*.txt 
HOS rm /u01/app/oracle/tools/cscripts/sql/*.html
HOS rm /u01/app/oracle/tools/cscripts/sql/*.zip
HOS rm /u01/app/oracle/tools/cscripts/sql/*.log
HOS rm /u01/app/oracle/tools/cscripts/sql/*.trc

HOS rm /u01/app/oracle/tools/sqld360/*.html
HOS rm /u01/app/oracle/tools/sqld360/*.zip

HOS rm /u01/app/oracle/tools/edb360/*.html
HOS rm /u01/app/oracle/tools/edb360/*.zip

HOS rm -r /u01/app/oracle/tools/cscripts/sql/iod_amw_reset
HOS rm -r /u01/app/oracle/tools/cscripts/sql/iod_rsrc_mgr
HOS rm -r /u01/app/oracle/tools/cscripts/sql/iod_spm_fpz
HOS rm -r /u01/app/oracle/tools/cscripts/sql/parse_test/
HOS rm -r /u01/app/oracle/tools/cscripts/sql/spm/

HOS rm /tmp/iod_spm_fpz_cdb_*.zip
HOS rm /tmp/purge_top_1*.zip
HOS rm /tmp/iod_spm_sentinel*.zip
HOS rm /tmp/iod_spm_fpz_ora*.zip
HOS rm /tmp/iod_spm_fpz_ora_*.zip
HOS rm /tmp/iod_spm_fpz_2018*.zip
HOS rm /tmp/iod_indexes_rebuild_online_2018*.txt
HOS rm /tmp/edb360*.zip
HOS rm /tmp/sqld360*.zip
