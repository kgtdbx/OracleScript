@@clean.sql
HOS rm /u01/app/oracle/tools/cscripts/sql/*.sql
EXIT
