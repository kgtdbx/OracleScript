DEF cuser = 'C##IOD';
@iod/iod_amw/setup.sql &&cuser.
PAUSE Hit "enter" to continue
@iod/iod_rsrc_mgr/setup.sql &&cuser.
PAUSE Hit "enter" to continue
@iod/iod_sess/setup.sql &&cuser.
PAUSE Hit "enter" to continue
@iod/iod_space/setup.sql &&cuser.
PAUSE Hit "enter" to continue
@iod/iod_spm/setup.sql &&cuser.
PAUSE Hit "enter" to continue
@source_version.sql