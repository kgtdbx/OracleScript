@iod_spm_fpz/setup c##iod
--@queries_on_small_tables_using_spb.sql
--@drop_spb_small_tables.sql
QUIT;

