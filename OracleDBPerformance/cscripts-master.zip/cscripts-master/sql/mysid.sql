SELECT sid, serial# FROM v$session WHERE sid = USERENV('SID')
/
