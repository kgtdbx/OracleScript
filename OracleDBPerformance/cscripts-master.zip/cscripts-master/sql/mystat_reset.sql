-- resets snaps credated by mystat.sql
DELETE plan_table WHERE statement_id = 'v$mystat';