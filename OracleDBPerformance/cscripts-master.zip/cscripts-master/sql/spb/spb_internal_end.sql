-- spb_internal_end.sql
-- close of spool and cleanup
-- this script is for internal use and only to be called from other scriprs

PRO
PRO &&output_file_name..txt
PRO

SPO OFF;
UNDEF 1 sql_id sql_handle signature
