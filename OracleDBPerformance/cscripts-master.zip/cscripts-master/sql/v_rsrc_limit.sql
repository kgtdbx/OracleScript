SELECT *
  FROM v$resource_limit
/
