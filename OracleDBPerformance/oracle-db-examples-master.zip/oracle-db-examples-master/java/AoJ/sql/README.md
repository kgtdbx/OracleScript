# Derby SQL

For use with AoJ (slitghly different from Oracle SQL)
