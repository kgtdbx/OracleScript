Copyright (c) Oracle and/or its affiliates. All rights reserved.

Oracle requires that contributors to all of its open-source projects sign the 
<a href="http://www.oracle.com/technetwork/community/oca-486395.html">Oracle Contributor Agreement (OCA)</a>.
