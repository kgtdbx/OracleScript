# JavaScript Examples

This directory contains Oracle Database JavaScript examples for:

- JavaScript on the JVM using the Nashorn engine (Hotspot JDk or JRE, other Java SE 8 compliant VMs, OJVM).
- node-oracledb for Node.js, allowing you to write mid-tier and networking applications in JavaScript.
- Creating a REST API with Node.js and Oracle Database.
