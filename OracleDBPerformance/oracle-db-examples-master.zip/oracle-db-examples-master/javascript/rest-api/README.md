# Creating a REST API with Node.js and Oracle Database

This folder contains sample code from the [Creating a REST API with Node.js and Oracle Database](https://jsao.io/2018/03/creating-a-rest-api-with-node-js-and-oracle-database/) blog series. See that post for more details.
