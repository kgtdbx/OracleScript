set echo on

spool example

@make_dim
@make_fact
@test_stats

spool off
