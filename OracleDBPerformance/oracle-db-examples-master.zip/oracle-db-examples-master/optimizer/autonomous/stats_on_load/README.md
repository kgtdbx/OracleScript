This example demonstrates that statistics are maintained during direct path load.

Create a test user using the *user.sql* script.

Run the test using *test_load.sql*.

### DISCLAIMER

*  These scripts are provided for educational purposes only.
*  They are NOT supported by Oracle World Wide Technical Support.
*  The scripts have been tested and they appear to work as intended.
*  You should always run scripts on a test instance.

### WARNING

*  These scripts drop and create tables. For use on test databases.
