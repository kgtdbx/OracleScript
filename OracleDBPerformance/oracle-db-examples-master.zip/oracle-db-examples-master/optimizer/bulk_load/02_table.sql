--
-- This creates the SALES staging table.
--
DROP TABLE sales_stage;

CREATE TABLE sales_stage
(id    NUMBER(10)
,txt   VARCHAR2(100)
);

