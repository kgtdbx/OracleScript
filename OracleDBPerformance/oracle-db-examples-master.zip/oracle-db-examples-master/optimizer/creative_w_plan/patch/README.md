# Examples of how you can to use SQL patch

See example.lst for the full scenario

The scripts assume you have a user account "adhoc/adhoc" - but you can 
change this in the scripts of course. Look for "connect adhoc/adhoc"

The scripts also assume you have privs to "connect / as sysdba".

### DISCLAIMER

*  These scripts are provided for educational purposes only.
*  They are NOT supported by Oracle World Wide Technical Support.
*  The scripts have been tested and they appear to work as intended.
*  You should always run scripts on a test instance.

### WARNING

*  These scripts drop and create tables. For use on test databases.
