select /* PROFTEST */ * from sales WHERE sale_date >= trunc(sysdate);
