create table ins(
 id number(10)
,t1 varchar2(100)
,t2 varchar2(100));

