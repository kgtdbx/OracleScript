grep "load_type" *.trc
