@cadm
exec dbms_stats.gather_database_stats()
