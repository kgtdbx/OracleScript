var tcount number

exec :tcount := 8
