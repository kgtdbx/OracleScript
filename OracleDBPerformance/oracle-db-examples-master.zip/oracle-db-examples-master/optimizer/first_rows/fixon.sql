alter session set "_fix_control"='22174392:ON';

