<h2>Parallel Execution and Workload Management Examples</h2>

Some scripts for setting up and monitoring parallel execution and Database Resource Manager in an EDW.

These scripts as in a very early state, so they have not been fully tested.

DISCLAIMER:
   <br/>-- These scripts are provided for educational purposes only.
   <br/>-- They are NOT supported by Oracle World Wide Technical Support.
   <br/>-- The scripts have been tested and they appear to work as intended.
   <br/>-- You should always run scripts on a test instance.

