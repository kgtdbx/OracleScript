<h2>SQL Plan Management Examples</h2>

Some scripts for trying out SQL Plan Management.

Just a few right now in the "inmem" folder, but expect more in the comming weeks.

DISCLAIMER:
   <br/>-- These scripts are provided for educational purposes only.
   <br/>-- They are NOT supported by Oracle World Wide Technical Support.
   <br/>-- The scripts have been tested and they appear to work as intended.
   <br/>-- You should always run scripts on a test instance.

