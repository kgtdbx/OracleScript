alter system set optimizer_capture_sql_plan_baselines=TRUE scope=memory;
