alter system set optimizer_capture_sql_plan_baselines=FALSE scope=memory;
