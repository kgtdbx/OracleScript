SELECT /* SPM */ COUNT(*)
FROM   mysales
WHERE  val = 'X';
