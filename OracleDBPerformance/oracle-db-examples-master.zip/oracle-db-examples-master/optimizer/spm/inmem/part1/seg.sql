SELECT segment_name,
       bytes,
       inmemory_size
FROM   v$im_segments;
  
