ALTER TABLE mysales NO INMEMORY;
ALTER SYSTEM flush shared_pool;
