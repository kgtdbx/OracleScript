blob_wrapper has moved to https://github.com/ReneNyffenegger/blob_wrapper-Oracle.
