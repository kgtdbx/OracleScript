create directory bmp_out_dir as 'c:\temp';
