drop directory bmp_out_dir;
