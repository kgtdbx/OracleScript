# call stack

A utility to analyse the call stack of `dbms_utility.format_call_stack`.

Originally written by GARBUYA, slightly adapted for my needs by myself.

A prerequisite for [operation_log](https://github.com/ReneNyffenegger/oracle_scriptlets/tree/master/operation_log).

Needs [source_code](https://github.com/ReneNyffenegger/oracle_scriptlets/tree/master/source_code).
