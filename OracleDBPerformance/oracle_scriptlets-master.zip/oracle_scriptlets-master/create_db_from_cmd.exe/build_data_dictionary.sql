shutdown
startup

-- @ runs a script
-- ? points to %ORACLE_HOME%

@?/rdbms/admin/catalog.sql
@?/rdbms/admin/catproc.sql

exit
