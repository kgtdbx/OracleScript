exec debugger.is_running
