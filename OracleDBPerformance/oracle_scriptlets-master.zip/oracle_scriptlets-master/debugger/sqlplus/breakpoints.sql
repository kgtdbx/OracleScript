exec debugger.breakpoints
