-- This script sets a breakpoint on a line
--   Most probably to be used for anonymous blocks
exec debugger.set_breakpoint(p_line=>&1)
