-- Starts the debugger, asks for a string that identifies 
-- the debugee. This string is obtained through running dbe.
exec debugger.start_debugger('&debugee_id')
