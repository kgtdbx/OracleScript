exec debugger.step
