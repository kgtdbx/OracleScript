exec debugger.print_var('&1');
