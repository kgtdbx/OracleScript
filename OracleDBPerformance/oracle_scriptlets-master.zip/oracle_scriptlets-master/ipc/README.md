See also [http://renenyffenegger.blogspot.ch/2014/11/bypassing-ora-00942-table-or-view-does.html](http://renenyffenegger.blogspot.ch/2014/11/bypassing-ora-00942-table-or-view-does.html).
