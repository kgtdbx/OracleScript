
A simple hierarchical logging functionality.

Needs [call_stack](https://github.com/ReneNyffenegger/oracle_scriptlets/tree/master/call_stack)
