create table tab_01 (
  id    number,
  text  varchar2(10)
);
