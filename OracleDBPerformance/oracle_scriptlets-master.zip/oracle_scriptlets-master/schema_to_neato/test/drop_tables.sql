drop table erd_child_2_x_erd_other purge;
drop table erd_other               purge;
drop table erd_child_2             purge;
drop table erd_child_1             purge;
drop table erd_parent              purge;
