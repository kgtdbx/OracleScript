# source code

`name_from_line`: Given the source code line of a package, get the name of the procedure/function for this line.

Originally written by GARBUYA, slightly modified for my needs by myself.

Used in [call_stack](https://github.com/ReneNyffenegger/oracle_scriptlets/tree/master/call_stack).

