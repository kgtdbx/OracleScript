select name, type, line, position, substr(text, 1, 90) from all_errors;
