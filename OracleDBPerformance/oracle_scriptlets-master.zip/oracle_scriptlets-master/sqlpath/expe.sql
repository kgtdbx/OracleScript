;

select * from table(dbms_xplan.display);

