explain plan for 
