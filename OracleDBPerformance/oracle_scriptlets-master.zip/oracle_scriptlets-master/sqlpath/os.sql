--
--     See also -> db.sql
--
select platform_name from v$database;
