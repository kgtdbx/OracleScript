@ps_ &1 print_upwards_graph
