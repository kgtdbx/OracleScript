alter system flush shared_pool;
alter system flush buffer_cache;
alter system flush global context;
alter system checkpoint;
