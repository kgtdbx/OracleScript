--
--    closes the spooling initiated by ./spool.sql
--
spool off
set lines            190
set pages           5000
set termout           on
