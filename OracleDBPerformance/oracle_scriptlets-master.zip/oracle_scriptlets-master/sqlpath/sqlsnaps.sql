--   This script goes along with ./sqlsnape.sql and ../sql_snap
--
--   It starts an SQL snap, to be ended with sqlsnape.sql
--
--   The same functionality, but without ../sql_snap package
--   is offered by sql_snap_t_s.sql/sql_snap_t_e.sql.
--
exec sql_snap.start_;
