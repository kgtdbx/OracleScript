select * from v$version;
