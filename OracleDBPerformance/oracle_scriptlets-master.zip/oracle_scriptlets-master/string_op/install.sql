define tq84_prefix=""
set    verify off

@@types.plsql

@@spec.plsql
@@body.plsql
