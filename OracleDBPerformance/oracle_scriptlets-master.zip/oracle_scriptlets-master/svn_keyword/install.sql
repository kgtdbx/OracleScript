@source_compilation.sql
@svn_keywords_in_source.sql
@create_package_trg.sql

@test.pks

select * from svn_keywords_in_source;
select * from source_compilation;
