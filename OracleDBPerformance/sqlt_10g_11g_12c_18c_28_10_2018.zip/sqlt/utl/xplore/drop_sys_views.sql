REM $Header: xplore/drop_sys_views.sql 11.4.3.2 2011/07/09 carlos.sierra $

DROP PUBLIC SYNONYM sqlt$_v$parameter_exadata;
DROP PUBLIC SYNONYM sqlt$_v$parameter_cbo;
DROP PUBLIC SYNONYM sqlt$_v$parameter_lov;

DROP VIEW sys.sqlt$_v$parameter_exadata;
DROP VIEW sys.sqlt$_v$parameter_cbo;
DROP VIEW sys.sqlt$_v$parameter_lov;
